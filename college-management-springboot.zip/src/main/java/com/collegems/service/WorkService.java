package com.collegems.service;

import com.collegems.model.Work;
import com.collegems.model.WorkAssignment;
import com.collegems.repository.WorkAssignmentRepository;
import com.collegems.repository.WorkRepository;
import com.collegems.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class WorkService {
    @Autowired private WorkRepository workRepo;
    @Autowired private WorkAssignmentRepository assignRepo;
    @Autowired private UserRepository userRepo;

    @Transactional
    public Work createWorkAndAssign(String title, String desc, LocalDate dueDate, String priority, Long principalId, List<Long> hodIds) {
        Work w = new Work();
        w.setTitle(title);
        w.setDescription(desc);
        w.setCreatedBy(principalId);
        w.setDueDate(dueDate);
        w.setPriority(priority);
        w.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        Work saved = workRepo.save(w);
        for(Long hid: hodIds){
            WorkAssignment wa = new WorkAssignment();
            wa.setWorkId(saved.getId());
            wa.setHodId(hid);
            wa.setStatus("assigned");
            wa.setAssignedAt(new Timestamp(System.currentTimeMillis()));
            assignRepo.save(wa);
        }
        return saved;
    }

    public List<WorkAssignment> getAssignmentsForHod(Long hodId){
        return assignRepo.findByHodIdOrderByAssignedAtDesc(hodId);
    }

    public Work getWorkById(Long id){
        return workRepo.findById(id).orElse(null);
    }

    public WorkAssignment updateAssignmentStatus(Long assignmentId, String status, String remarks, Long actorId, String actorRole){
        WorkAssignment wa = assignRepo.findById(assignmentId).orElseThrow(() -> new RuntimeException("Assignment not found"));
        if("hod".equalsIgnoreCase(actorRole) && !wa.getHodId().equals(actorId)){
            throw new RuntimeException("Not allowed");
        }
        wa.setStatus(status);
        if("completed".equalsIgnoreCase(status)) wa.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        wa.setRemarks(remarks);
        return assignRepo.save(wa);
    }
}
