package com.collegems.dto;

public class UpdateStatusRequest {
    public String status;
    public String remarks;
}
