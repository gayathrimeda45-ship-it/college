package com.collegems.dto;

import com.collegems.model.WorkAssignment;
import com.collegems.model.Work;

public class WorkAssignmentDTO {
    public Long id;
    public String status;
    public String remarks;
    public String assignedAt;
    public String completedAt;
    public Work work;

    public WorkAssignmentDTO(WorkAssignment wa, Work w) {
        this.id = wa.getId();
        this.status = wa.getStatus();
        this.remarks = wa.getRemarks();
        this.assignedAt = wa.getAssignedAt() != null ? wa.getAssignedAt().toString() : null;
        this.completedAt = wa.getCompletedAt() != null ? wa.getCompletedAt().toString() : null;
        this.work = w;
    }
}
