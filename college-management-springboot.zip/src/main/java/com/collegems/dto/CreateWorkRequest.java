package com.collegems.dto;

import java.time.LocalDate;
import java.util.List;

public class CreateWorkRequest {
    public String title;
    public String description;
    public List<Long> hodIds;
    public LocalDate dueDate;
    public String priority;
}
