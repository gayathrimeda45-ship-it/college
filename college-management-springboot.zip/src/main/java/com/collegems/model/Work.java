package com.collegems.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.sql.Timestamp;

@Entity
@Table(name = "works")
public class Work {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    @Column(columnDefinition = "TEXT")
    private String description;
    @Column(name = "created_by")
    private Long createdBy;
    @Column(name = "due_date")
    private LocalDate dueDate;
    private String priority;
    @Column(name = "created_at")
    private Timestamp createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = new Timestamp(System.currentTimeMillis());
    }

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getTitle(){return title;}
    public void setTitle(String t){this.title=t;}
    public String getDescription(){return description;}
    public void setDescription(String d){this.description=d;}
    public Long getCreatedBy(){return createdBy;}
    public void setCreatedBy(Long c){this.createdBy=c;}
    public LocalDate getDueDate(){return dueDate;}
    public void setDueDate(LocalDate d){this.dueDate=d;}
    public String getPriority(){return priority;}
    public void setPriority(String p){this.priority=p;}
    public Timestamp getCreatedAt(){return createdAt;}
    public void setCreatedAt(Timestamp t){this.createdAt=t;}
}
