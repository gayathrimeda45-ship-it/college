package com.collegems.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "work_assignments")
public class WorkAssignment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "work_id")
    private Long workId;
    @Column(name = "hod_id")
    private Long hodId;
    private String status; // assigned,in_progress,completed
    @Column(name = "assigned_at")
    private Timestamp assignedAt;
    @Column(name = "completed_at")
    private Timestamp completedAt;
    @Column(columnDefinition = "TEXT")
    private String remarks;

    @PrePersist
    public void prePersist() {
        this.assignedAt = new Timestamp(System.currentTimeMillis());
        if (this.status == null) this.status = "assigned";
    }

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getWorkId(){return workId;}
    public void setWorkId(Long w){this.workId=w;}
    public Long getHodId(){return hodId;}
    public void setHodId(Long h){this.hodId=h;}
    public String getStatus(){return status;}
    public void setStatus(String s){this.status=s;}
    public Timestamp getAssignedAt(){return assignedAt;}
    public void setAssignedAt(Timestamp t){this.assignedAt=t;}
    public Timestamp getCompletedAt(){return completedAt;}
    public void setCompletedAt(Timestamp t){this.completedAt=t;}
    public String getRemarks(){return remarks;}
    public void setRemarks(String r){this.remarks=r;}
}
