package com.collegems.repository;

import com.collegems.model.WorkAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface WorkAssignmentRepository extends JpaRepository<WorkAssignment, Long> {
    List<WorkAssignment> findByHodIdOrderByAssignedAtDesc(Long hodId);
    List<WorkAssignment> findByWorkId(Long workId);
}
