package com.collegems.controller;

import com.collegems.dto.CreateWorkRequest;
import com.collegems.dto.UpdateStatusRequest;
import com.collegems.dto.WorkAssignmentDTO;
import com.collegems.model.User;
import com.collegems.model.Work;
import com.collegems.model.WorkAssignment;
import com.collegems.repository.UserRepository;
import com.collegems.service.WorkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class WorkController {
    @Autowired private WorkService workService;
    @Autowired private UserRepository userRepo;

    @GetMapping("/hods")
    public List<User> getHods(@RequestHeader(value="X-User-Id", required=false) Long uid,
                              @RequestHeader(value="X-User-Role", required=false) String role) {
        // simple: return all users with role 'hod'
        return userRepo.findByRole("hod");
    }

    @PostMapping("/works")
    public ResponseEntity<?> createWork(@RequestBody CreateWorkRequest req,
                                        @RequestHeader(value="X-User-Id", required=false) Long userId,
                                        @RequestHeader(value="X-User-Role", required=false) String role) {
        if(!"principal".equalsIgnoreCase(role)) return ResponseEntity.status(HttpStatus.FORBIDDEN).body("only principal allowed");
        Work w = workService.createWorkAndAssign(req.title, req.description, req.dueDate, req.priority, userId, req.hodIds);
        return ResponseEntity.status(HttpStatus.CREATED).body(w);
    }

    @GetMapping("/assignments")
    public ResponseEntity<?> getAssignments(@RequestHeader(value="X-User-Id", required=false) Long userId,
                                            @RequestHeader(value="X-User-Role", required=false) String role) {
        if(!"hod".equalsIgnoreCase(role)) return ResponseEntity.status(HttpStatus.FORBIDDEN).body("only hod allowed");
        List<WorkAssignment> list = workService.getAssignmentsForHod(userId);
        List<WorkAssignmentDTO> dtos = list.stream().map(wa -> {
            Work w = workService.getWorkById(wa.getWorkId());
            return new WorkAssignmentDTO(wa, w);
        }).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PatchMapping("/assignments/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestBody UpdateStatusRequest req,
                                          @RequestHeader(value="X-User-Id", required=false) Long userId,
                                          @RequestHeader(value="X-User-Role", required=false) String role) {
        try {
            WorkAssignment wa = workService.updateAssignmentStatus(id, req.status, req.remarks, userId, role);
            return ResponseEntity.ok(wa);
        } catch(Exception ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }
}
