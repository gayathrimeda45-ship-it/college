# College Management System (Principal → HOD Work Assignment)

This is a minimal Spring Boot project with static HTML/CSS/vanilla JS pages demonstrating the workflow:
- Principal assigns works to one or more HODs.
- HOD views assignments and marks them completed.

## Contents
- Spring Boot backend (src/main/java/com/collegems)
- Static frontend pages in `src/main/resources/static`:
  - principal.html
  - hod.html

## Quick start (local)
1. Install Java 17 and Maven.
2. Create a MySQL database (or PostgreSQL; adjust `application.properties`).
3. Update `src/main/resources/application.properties` with DB credentials.
4. (Optional) Insert sample users into `users` table (see `schema.sql`).
5. Build and run:
   ```bash
   mvn clean package
   mvn spring-boot:run
   ```
6. Open:
   - http://localhost:8080/principal.html
   - http://localhost:8080/hod.html

Notes:
- This demo uses simple header-based "fake" auth: frontend sets `X-User-Id` and `X-User-Role` headers.
- Replace with Spring Security for production.
